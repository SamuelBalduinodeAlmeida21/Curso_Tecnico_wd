#Prog_8
x = "Pedro"
print(x)

#aspas duplas são o mesmo que aspas simples

x = 'Pedro'
print(x)