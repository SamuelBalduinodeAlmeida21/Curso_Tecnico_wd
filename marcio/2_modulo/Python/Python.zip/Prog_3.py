#Prog_3
print("Fala aí pessoal!")