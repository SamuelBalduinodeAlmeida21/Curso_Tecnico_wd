# um valor para várias variáveis
x = y = z = "Livro"
print(x)
print(y)
print(z)