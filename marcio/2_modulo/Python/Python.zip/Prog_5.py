#Prog_5
x = 4
x = "Maria"
print(x)

#quando usamos print estamos basicmanete pegando o último valor dado a uma variável igual a outra, no caso  "x" e "x" porém, com valores distintos