#Prog_10
"""============================"""
#Um nome de uma variável deve começar com uma letra ou caractere especial;
#Um nome de uma varável não pode começçar com um número 
#Além do alfanumérico (letras e números), um nome de variável pode ter somente o caractere underline;
#Nomes de variáveis diferenciam maiúsculas de minúsculas;

minhavariavel = 10
minha_variavel = 10
_minha_variavel = 10
minhaVariavel = 10
MINHAVARIAVEL = 10
print(minhavariavel)
print(minha_variavel)
print(_minha_variavel)
print(minhaVariavel)
print(MINHAVARIAVEL)
