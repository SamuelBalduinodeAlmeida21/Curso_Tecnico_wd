#Prog_4

x = 10
y = "Josemar"
print(x)
print(y)