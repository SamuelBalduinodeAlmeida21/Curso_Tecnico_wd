#Prog_9

a = 4
A = 6
#A variável 'A' não subistituirá a variável 'a', pois o python é case sensitive
print(a)
print(A)