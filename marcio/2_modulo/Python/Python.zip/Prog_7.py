"""Prog_7"""
#Você pode obter o tipo de dados da variável através do comando type
x = 3
y = "Pedro"
print(type(x))
print(type(y))