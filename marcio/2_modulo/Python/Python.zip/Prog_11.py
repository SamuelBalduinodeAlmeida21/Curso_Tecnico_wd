#um valor para cada variável
x, y, z = "caderno", "lápis" , "borracha"
print(x)
print(y)
print(z)