# Este é apenas um comentário na linguagem Python, no é parecido com JavaScript, a hashtag se usa para epnas uma linha de comentário continua;

"""E usamos aspas triplas para um comentário de quantas linhas quiseres;"""

nome = "Prof. Marcio"
Aluno = "Ou estudante da linguagem"
print("Bem vindo ao python,",nome,Aluno,"!")

"""=============================================================="""


