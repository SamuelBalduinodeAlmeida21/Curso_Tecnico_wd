#Prog_2
nome  = "Samuel"
sobrenome = "Balduino de Almeida"

print("O seu nome completo é ",nome,sobrenome)