#Você pode especifícar o tipo de uma variável
x = str(3)
y = int(8)
z = float(3)
print(x)
print(y)
print(z)

"""STR quer dizer string, INT, quer dizer inteiro, e FLOAT quer dizer decimal"""